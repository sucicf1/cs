﻿namespace zad3.ViewModel
{
    public class House : Item
    {
        public bool IsFlatRoof { get; set; }
        public int NumberOfFloors { get; set; }
    }
}
