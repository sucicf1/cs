﻿namespace zad3.ViewModel
{
    public class Person : Item
    {
        public int Age { get; set; }
        public string Address { get; set; }
    }
}
