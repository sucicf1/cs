﻿namespace zad3.ViewModel
{
    public class Car : Item
    {
        public string Type { get; set; }
        public string Color { get; set; }
    }
}
